package application;

public class Controller {
	public void CalcGrossClicked() {
		
	}

}
